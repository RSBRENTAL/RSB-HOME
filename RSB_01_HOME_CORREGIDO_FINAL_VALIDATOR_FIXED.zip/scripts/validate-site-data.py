#!/usr/bin/env python3
import json
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAGES = {
    'index.html': 'en', 'es/index.html': 'es', 'fr/index.html': 'fr',
    'it/index.html': 'it', 'de/index.html': 'de', 'nl/index.html': 'nl',
    'pt/index.html': 'pt', 'cat/index.html': 'ca', 'sv/index.html': 'sv',
    'pl/index.html': 'pl',
}
ERRORS = []

def bad(filename, description):
    ERRORS.append(f'ERROR: {filename}: {description}')

def get(obj, path):
    for key in path.split('.'):
        if not isinstance(obj, dict) or key not in obj:
            return None
        obj = obj[key]
    return obj

def expect(filename, obj, path, expected):
    actual = get(obj, path)
    if actual != expected:
        bad(filename, f'{path} expected {expected!r}, got {actual!r}')

def numeric_equal(value, expected):
    try:
        return float(value) == float(expected)
    except (TypeError, ValueError):
        return False

def load_json(rel):
    path = ROOT / rel
    if not path.exists():
        bad(rel, 'file missing')
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        bad(rel, f'invalid JSON ({exc})')
        return None

def all_nodes(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from all_nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from all_nodes(child)

def type_has(node, wanted):
    value = node.get('@type') if isinstance(node, dict) else None
    return wanted in value if isinstance(value, list) else value == wanted

def service_by_id(data, service_id):
    if not isinstance(data, dict):
        return None
    for service in data.get('services', []):
        if isinstance(service, dict) and service.get('id') == service_id:
            return service
    return None

def text_contains(container, phrase):
    if isinstance(container, str):
        return phrase in container
    if isinstance(container, list):
        return any(text_contains(x, phrase) for x in container)
    if isinstance(container, dict):
        return any(text_contains(x, phrase) for x in container.values())
    return False

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.canonicals = []
        self.metas = {}
        self.ids = {}
        self.faq_items = 0
        self.faq_q = 0
        self.controls = {}
        self.jsonld = []
        self._in_jsonld = False
        self._json_parts = []
        self._reviews_depth = None
        self._depth = 0
        self.review_articles = 0
        self.review_forbidden = []
        self.language_forbidden = []
        self._lang_depths = []

    def handle_starttag(self, tag, attrs):
        self._depth += 1
        a = dict(attrs)
        classes = set(a.get('class', '').split())
        ident = a.get('id')
        if ident:
            self.ids[ident] = self.ids.get(ident, 0) + 1
        if tag == 'link' and 'canonical' in a.get('rel', '').split():
            self.canonicals.append(a.get('href'))
        if tag == 'meta' and a.get('name') in ('geo.position', 'ICBM'):
            self.metas.setdefault(a['name'], []).append(a.get('content'))
        if 'faq-item' in classes:
            self.faq_items += 1
        if 'faq-q' in classes:
            self.faq_q += 1
        if ident and 'aria-controls' in a:
            self.controls[ident] = a.get('aria-controls')
        if ident == 'reviews':
            self._reviews_depth = self._depth
        if self._reviews_depth is not None and self._depth > self._reviews_depth:
            if tag == 'article':
                self.review_articles += 1
            for key, val in attrs:
                if key == 'role' and val in ('list', 'listitem'):
                    self.review_forbidden.append(f'role="{val}"')
        if ident in ('langDropdown', 'langDropdownMobile', 'langMenu', 'langMenuMobile', 'langTrigger', 'langTriggerMobile'):
            self._lang_depths.append(self._depth)
        if self._lang_depths and self._depth >= min(self._lang_depths):
            for key, val in attrs:
                if (key == 'role' and val in ('menu', 'menuitem')) or (key == 'aria-haspopup' and val == 'menu'):
                    self.language_forbidden.append(f'{key}="{val}"')
        if tag == 'script' and a.get('type', '').lower() == 'application/ld+json':
            self._in_jsonld = True
            self._json_parts = []

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_data(self, data):
        if self._in_jsonld:
            self._json_parts.append(data)

    def handle_endtag(self, tag):
        if tag == 'script' and self._in_jsonld:
            self.jsonld.append(''.join(self._json_parts))
            self._in_jsonld = False
            self._json_parts = []
        if self._reviews_depth == self._depth:
            self._reviews_depth = None
        self._lang_depths = [d for d in self._lang_depths if d != self._depth]
        self._depth = max(0, self._depth - 1)

# A — canonical site data
site = load_json('data/site-data.json')
if site is not None:
    expected_site = {
        'schemaVersion': 1,
        'business.name': 'RSB Rental Scooter Barcelona',
        'business.website': 'https://rentalscooterbarcelona.com/',
        'business.telephoneDisplay': '+34 640 559 468',
        'business.telephoneE164': '+34640559468',
        'business.whatsapp': 'https://wa.me/34640559468',
        'business.email': 'info@rentalscooterbarcelona.com',
        'business.address.streetAddress': 'Carrer de Salvador Espriu, 63',
        'business.address.postalCode': '08005',
        'business.address.addressLocality': 'Barcelona',
        'business.address.addressRegion': 'Catalonia',
        'business.address.addressCountry': 'ES',
        'geo.latitude': 41.3906488, 'geo.longitude': 2.1984312,
        'maps.googleCid': '912877649802486634',
        'maps.googleUrl': 'https://www.google.com/maps?cid=912877649802486634',
        'maps.applePlaceId': 'IA5C7938C1925731A',
        'maps.bingLocalYpid': 'YND84466019C726C1',
        'reviews.ratingValue': 4.6, 'reviews.reviewCount': 226,
        'reviews.bestRating': 5, 'reviews.worstRating': 1,
        'currency': 'EUR', 'faqArchitecture.publicHomeFaqCount': 9,
        'faqArchitecture.aiFaqCount': 12,
    }
    for path, value in expected_site.items():
        expect('data/site-data.json', site, path, value)

# B — ten HOME HTML files
if site is not None:
    for rel, lang in PAGES.items():
        path = ROOT / rel
        if not path.exists():
            bad(rel, 'file missing')
            continue
        try:
            html = path.read_text(encoding='utf-8')
        except (OSError, UnicodeError) as exc:
            bad(rel, f'cannot read file ({exc})')
            continue
        parser = PageParser()
        try:
            parser.feed(html)
        except Exception as exc:
            bad(rel, f'HTML parsing failed ({exc})')
            continue
        canonical = get(site, f'languages.{lang}')
        if parser.canonicals != [canonical]:
            bad(rel, f'canonical expected exactly {canonical!r}, got {parser.canonicals!r}')
        if parser.metas.get('geo.position') != ['41.3906488;2.1984312']:
            bad(rel, 'geo.position is not exactly 41.3906488;2.1984312')
        if parser.metas.get('ICBM') != ['41.3906488, 2.1984312']:
            bad(rel, 'ICBM is not exactly 41.3906488, 2.1984312')
        for obsolete in ('41.390577', '2.198362'):
            if obsolete in html:
                bad(rel, f'obsolete coordinate {obsolete}')
        apple_urls = re.findall(r'https://maps\.apple\.com/[^\s"\'<>]+', html)
        if not apple_urls:
            bad(rel, 'Apple Maps URL missing')
        for url in apple_urls:
            if 'coordinate=41.3906488%2C2.1984312' not in url:
                bad(rel, 'Apple Maps URL has incorrect coordinate')
        decoded = []
        for i, block in enumerate(parser.jsonld, 1):
            try:
                decoded.append(json.loads(block))
            except json.JSONDecodeError as exc:
                bad(rel, f'JSON-LD block {i} invalid ({exc})')
        nodes = [node for doc in decoded for node in all_nodes(doc)]
        orgs = [n for n in nodes if type_has(n, 'Organization') and n.get('name') == 'RSB Rental Scooter Barcelona']
        if not orgs:
            bad(rel, 'main Organization not found')
        else:
            org = orgs[0]
            checks = {
                'name':'RSB Rental Scooter Barcelona','telephone':'+34 640 559 468','email':'info@rentalscooterbarcelona.com',
                'address.streetAddress':'Carrer de Salvador Espriu, 63','address.postalCode':'08005',
                'address.addressLocality':'Barcelona','address.addressRegion':'Catalonia','address.addressCountry':'ES'}
            for key, val in checks.items():
                if get(org, key) != val: bad(rel, f'Organization {key} mismatch')
        lbs = [n for n in nodes if type_has(n, 'LocalBusiness') and isinstance(n.get('address'), dict) and isinstance(n.get('geo'), dict)]
        if not lbs:
            bad(rel, 'main LocalBusiness with address + geo not found')
        else:
            lb = lbs[0]
            checks = {
                'name':'RSB Rental Scooter Barcelona','telephone':'+34 640 559 468','email':'info@rentalscooterbarcelona.com',
                'address.streetAddress':'Carrer de Salvador Espriu, 63','address.postalCode':'08005',
                'address.addressLocality':'Barcelona','address.addressRegion':'Catalonia','address.addressCountry':'ES',
                'geo.latitude':41.3906488,'geo.longitude':2.1984312,
                'hasMap':'https://www.google.com/maps?cid=912877649802486634'}
            for key, val in checks.items():
                if get(lb, key) != val: bad(rel, f'LocalBusiness {key} mismatch')
            specs = lb.get('openingHoursSpecification')
            expected_days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
            expected_periods = [('10:30','13:30'),('16:30','20:00')]
            if not isinstance(specs, list) or len(specs) != 2:
                bad(rel, 'expected exactly two OpeningHoursSpecification entries')
            else:
                actual_periods = []
                for spec in specs:
                    if not type_has(spec, 'OpeningHoursSpecification') or spec.get('dayOfWeek') != expected_days:
                        bad(rel, 'OpeningHoursSpecification days/type mismatch')
                    actual_periods.append((spec.get('opens'), spec.get('closes')))
                if actual_periods != expected_periods:
                    bad(rel, f'opening periods mismatch: {actual_periods!r}')
        ratings = [n for n in nodes if type_has(n, 'AggregateRating')]
        if not ratings:
            bad(rel, 'AggregateRating not found')
        else:
            rating = ratings[0]
            for key, val in [('ratingValue',4.6),('reviewCount',226),('bestRating',5),('worstRating',1)]:
                if not numeric_equal(rating.get(key), val): bad(rel, f'AggregateRating {key} mismatch')
        if re.search(r'(?i)(?:reviewCount|Google\s+reviews?)[^\n<]{0,50}\b(?:221|222)\b|\b(?:221|222)\b[^\n<]{0,50}(?:Google\s+reviews?)', html):
            bad(rel, 'obsolete Google review total 221/222')
        if parser.faq_items != 9: bad(rel, f'expected exactly 9 .faq-item, got {parser.faq_items}')
        if parser.faq_q != 9: bad(rel, f'expected exactly 9 .faq-q, got {parser.faq_q}')
        for i in range(1,10):
            b, p = f'faq-button-{i}', f'faq-panel-{i}'
            if parser.ids.get(b,0) != 1: bad(rel, f'expected exactly one id={b}')
            if parser.ids.get(p,0) != 1: bad(rel, f'expected exactly one id={p}')
            if parser.controls.get(b) != p: bad(rel, f'{b} aria-controls must be {p}')
        if parser.review_articles != 3: bad(rel, f'expected exactly 3 review articles, got {parser.review_articles}')
        for item in sorted(set(parser.review_forbidden)): bad(rel, f'forbidden in #reviews: {item}')
        for item in sorted(set(parser.language_forbidden)): bad(rel, f'forbidden in language selectors: {item}')
        for ident, target in [('langTrigger','langMenu'),('langTriggerMobile','langMenuMobile'),('mobileMenuBtn','mobileMenu')]:
            if parser.controls.get(ident) != target: bad(rel, f'{ident} aria-controls must be {target}')
        if parser.ids.get('langMenu',0) != 1: bad(rel, 'id=langMenu must exist exactly once')
        if parser.ids.get('langMenuMobile',0) != 1: bad(rel, 'id=langMenuMobile must exist exactly once')

# C — multilingual URLs
multi = load_json('multilingual-urls.json')
if multi is not None and site is not None:
    home = get(multi, 'pages.home')
    languages = site.get('languages')
    if home != languages: bad('multilingual-urls.json', 'pages.home does not exactly match site-data.json languages')
    expected_codes = {'en','es','fr','it','de','nl','pt','ca','sv','pl'}
    if not isinstance(home, dict) or set(home) != expected_codes: bad('multilingual-urls.json', 'pages.home language codes mismatch')

# D — services
services = load_json('services.json')
if services is not None:
    for key, val in {
        'business.name':'RSB Rental Scooter Barcelona','business.website':'https://rentalscooterbarcelona.com/',
        'business.address.street':'Carrer de Salvador Espriu, 63','business.address.postalCode':'08005','business.address.city':'Barcelona',
        'business.phone':'+34 640 559 468','business.whatsapp':'https://wa.me/34640559468','business.email':'info@rentalscooterbarcelona.com'}.items(): expect('services.json',services,key,val)
    if get(services,'business.openingHours') != [{'days':'Every day','hours':'10:30-13:30'},{'days':'Every day','hours':'16:30-20:00'}]: bad('services.json','opening hours mismatch')
    gr = get(services,'business.googleReviews')
    if not isinstance(gr,str) or not re.search(r'\b4\.6\b',gr) or not re.search(r'\b226\b',gr): bad('services.json','googleReviews must reflect 4.6 and 226')
    if isinstance(gr,str) and re.search(r'\b(?:221|222)\b',gr): bad('services.json','obsolete Google review total 221/222')
    scooter = service_by_id(services,'scooter-rental-barcelona')
    for phrase in ['A refundable security deposit applies only to motor scooter rentals','Free hotel delivery for rentals of 3+ days']:
        if not text_contains(scooter,phrase): bad('services.json',f'scooter service missing {phrase!r}')
    for sid in ['bike-rental-barcelona','inline-skates-rental-barcelona','roller-skates-rental-barcelona','skateboard-rental-barcelona','longboard-rental-barcelona']:
        if not text_contains(service_by_id(services,sid),'No deposit'): bad('services.json',f'{sid} missing No deposit')

# E — prices
prices = load_json('prices.json')
if prices is not None:
    for key,val in {'business.name':'RSB Rental Scooter Barcelona','business.website':'https://rentalscooterbarcelona.com/','business.currency':'EUR','business.location.street':'Carrer de Salvador Espriu, 63','business.location.city':'Barcelona','business.contact.phone':'+34 640 559 468','business.contact.whatsapp':'https://wa.me/34640559468','business.contact.email':'info@rentalscooterbarcelona.com'}.items(): expect('prices.json',prices,key,val)
    required = {
        'bike-rental-barcelona':['Helmet for children','Bike lock'],
        'inline-skates-rental-barcelona':['Helmet for children','Pads for knees, elbows and wrists'],
        'roller-skates-rental-barcelona':['Helmet for children','Pads for knees, elbows and wrists'],
        'skateboard-rental-barcelona':['Helmet for children','Pads for knees, elbows and wrists'],
        'longboard-rental-barcelona':['Helmet for children','Pads for knees, elbows and wrists'],
        'scooter-rental-barcelona':['Free hotel delivery for rentals of 3+ days','A refundable security deposit applies only to motor scooter rentals','Helmets and insurance included']}
    for sid, phrases in required.items():
        service = service_by_id(prices,sid)
        if service is None: bad('prices.json',f'service {sid} missing'); continue
        for phrase in phrases:
            if not text_contains(service,phrase): bad('prices.json',f'{sid} missing {phrase!r}')

# F — FAQ
faq = load_json('faq.json')
if faq is not None:
    for key,val in {'business.name':'RSB Rental Scooter Barcelona','business.website':'https://rentalscooterbarcelona.com/','business.contact.phone':'+34 640 559 468','business.contact.whatsapp':'https://wa.me/34640559468','business.contact.email':'info@rentalscooterbarcelona.com'}.items(): expect('faq.json',faq,key,val)
    if not isinstance(faq.get('faqs'),list) or len(faq['faqs']) != 12: bad('faq.json','faqs must contain exactly 12 items')
    faq_text = json.dumps(faq,ensure_ascii=False)
    for phrase in ['Carrer de Salvador Espriu, 63, 08005 Barcelona','3 or more days','No deposit is required for bikes, inline skates, roller skates, skateboards and longboards','security deposit applies only to motor scooters','10:30 to 13:30','16:30 to 20:00','https://wa.me/34640559468','+34 640 559 468']:
        if phrase.lower() not in faq_text.lower(): bad('faq.json',f'canonical FAQ fact missing: {phrase!r}')

# G — agents.md
agents_path = ROOT/'agents.md'
if not agents_path.exists(): bad('agents.md','file missing')
else:
    agents = agents_path.read_text(encoding='utf-8')
    for phrase in ['RSB Rental Scooter Barcelona','Carrer de Salvador Espriu, 63, 08005 Barcelona, Spain','+34 640 559 468','info@rentalscooterbarcelona.com','10:30-13:30','16:30-20:00','three or more days','No deposit applies to bikes, inline skates, quad roller skates, skateboards and longboards','security deposit applies only to motor scooter rentals','child helmet, wrist guards, knee pads and elbow pads','Bike rentals include a child helmet and a lock','Motor scooter rentals include two helmets and third-party insurance']:
        if phrase.lower() not in agents.lower(): bad('agents.md',f'required fact missing: {phrase!r}')

# H/I — llms conditional consistency
for rel in ('llms.txt','llms-full.txt'):
    path=ROOT/rel
    if not path.exists(): bad(rel,'file missing'); continue
    text=path.read_text(encoding='utf-8')
    lower=text.lower()
    if re.search(r'(?i)(?:Google\s+reviews?|Reviews?)[^\n]{0,60}\b(?:221|222)\b|\b(?:221|222)\b[^\n]{0,60}(?:Google\s+reviews?|Reviews?)',text): bad(rel,'obsolete Google review total 221/222')

    lines=text.splitlines()
    for line in lines:
        stripped=line.strip()
        plain=re.sub(r'^[-*]\s*', '', stripped)

        # Every identifiable current review/rating declaration must carry both canonical values.
        if re.search(r'(?i)^(?:reviews?|rating)\s*:', plain) or re.search(r'(?i)google\s+reviews?', plain):
            if not ('4.6' in line and re.search(r'(?<!\d)226(?!\d)', line)):
                bad(rel,'reviews must be 4.6 / 226')

        # Every explicit phone declaration must use the canonical display number.
        if re.search(r'(?i)^phone(?:\s+and\s+whatsapp)?\s*:', plain):
            if '+34 640 559 468' not in line:
                bad(rel,'phone mismatch')

        # Every explicit Email declaration must use the canonical address. If it is a
        # Markdown mailto declaration, both the visible address and mailto target must match.
        if re.search(r'(?i)^email\s*:', plain):
            if 'info@rentalscooterbarcelona.com' not in line:
                bad(rel,'email mismatch')
            if 'mailto:' in line.lower() and '[info@rentalscooterbarcelona.com](mailto:info@rentalscooterbarcelona.com)' not in line:
                bad(rel,'email mismatch')

        # Generic statements such as "WhatsApp booking is available" are intentionally ignored.
        if re.search(r'(?i)^whatsapp(?:\s+booking)?\s*:', plain) or re.search(r'(?i)^phone\s+and\s+whatsapp\s*:', plain):
            if 'wa.me/' in line.lower() and 'https://wa.me/34640559468' not in line:
                bad(rel,'WhatsApp URL mismatch')
            if re.search(r'(?<!\d)\+\d[\d \-.()]{7,}\d', line) and '+34 640 559 468' not in line:
                bad(rel,'WhatsApp number mismatch')

        # Every explicit opening-hours declaration must contain both canonical periods.
        if re.search(r'(?i)^opening hours\s*:', plain):
            if not all(v in line for v in ('10:30','13:30','16:30','20:00')):
                bad(rel,'opening hours mismatch')

        # Only concrete hotel-delivery minimum-duration declarations are constrained.
        if re.search(r'(?i)hotel.*delivery|delivery.*hotel', line) and re.search(r'(?i)\bdays?\b', line):
            if not re.search(r'(?i)(3\+\s*days|3\s+or\s+more\s+days|three\s+or\s+more\s+days)', line):
                bad(rel,'hotel delivery duration mismatch')

    # Validate deposit declarations in context, so a correct declaration cannot mask a contradictory one.
    current_service=None
    no_deposit_services=('inline skates','bike','roller skates','skateboard','longboard')
    for line in lines:
        heading=re.match(r'^###\s+(.+?)\s*$', line.strip())
        if heading:
            current_service=heading.group(1).lower()
            continue
        low=line.lower()
        if 'no deposit' in low:
            if current_service is not None:
                if 'scooter' in current_service:
                    bad(rel,'motor scooter must not be declared no-deposit')
                elif not any(service in current_service for service in no_deposit_services):
                    bad(rel,'no-deposit declaration is attached to an unknown service')
            else:
                if not all(word in low for word in ('bike','inline','roller','skateboard','longboard')):
                    bad(rel,'No deposit declaration missing canonical service coverage')
                if not re.search(r'(?i)security deposit[^\n.]*only[^\n.]*motor scooters?|only[^\n.]*motor scooters?[^\n.]*security deposit', line):
                    bad(rel,'security deposit must be scooter-only')
        if current_service is not None and any(service in current_service for service in no_deposit_services):
            if re.search(r'(?i)(?:security\s+)?deposit.*(?:required|applies)|(?:required|applies).*(?:security\s+)?deposit', line):
                bad(rel,f'{current_service} must be no-deposit')
        if 'security deposit' in low and current_service is None:
            if not re.search(r'(?i)security deposit[^\n.]*only[^\n.]*motor scooters?|only[^\n.]*motor scooters?[^\n.]*security deposit',line):
                bad(rel,'security deposit must be scooter-only')

# J — obsolete coordinates in all analyzed files and contextual old review totals
analyzed = list(PAGES) + ['data/site-data.json','multilingual-urls.json','services.json','prices.json','faq.json','agents.md','llms.txt','llms-full.txt']
for rel in analyzed:
    path=ROOT/rel
    if not path.exists(): continue
    text=path.read_text(encoding='utf-8')
    for obsolete in ('41.390577','2.198362'):
        if obsolete in text: bad(rel,f'obsolete coordinate {obsolete}')

if ERRORS:
    print('\n'.join(ERRORS))
    sys.exit(1)
print('OK: site data validation passed')
